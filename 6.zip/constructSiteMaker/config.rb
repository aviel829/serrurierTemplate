
#preferred_syntax = :sass

http_path = '/'
http_fonts_path = './'
http_fonts_dir = 'style/fonts/'
css_dir = './'
sass_dir = 'sass/'
images_dir = 'images/'
javascripts_dir = 'js/'

preferred_syntax = :scss
relative_assets = false
line_comments = false
output_style = :compressed
